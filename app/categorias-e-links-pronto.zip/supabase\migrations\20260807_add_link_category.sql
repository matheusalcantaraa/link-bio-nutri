alter table public.links_pdf
add column if not exists categoria text not null default 'Geral';
